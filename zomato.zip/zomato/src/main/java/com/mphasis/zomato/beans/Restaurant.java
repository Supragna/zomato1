package com.mphasis.zomato.beans;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="restaurant")
public class Restaurant {
	@Id
	private String rname;
	private String address;
	@ManyToOne
	private Cuisine cuisine;
	@OneToMany(mappedBy="restaurant")
	private List<Orders> orders;
	@Override
	public String toString() {
		return "Restaurant [rname=" + rname + ", address=" + address + ", cuisine=" + cuisine + ", orders=" + orders
				+ "]";
	}
	
	
	


	public Cuisine getCuisine() {
		return cuisine;
	}





	public void setCuisine(Cuisine cuisine) {
		this.cuisine = cuisine;
	}





	public List<Orders> getOrders() {
		return orders;
	}


	public void setOrders(List<Orders> orders) {
		this.orders = orders;
	}


	public String getRname() {
		return rname;
	}
	public void setRname(String rname) {
		this.rname = rname;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	
	}


