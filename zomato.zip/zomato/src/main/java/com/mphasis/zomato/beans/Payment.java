package com.mphasis.zomato.beans;

import javax.persistence.Entity;
import javax.persistence.Id;

import javax.persistence.Table;

@Entity
@Table(name="payment")
public class Payment {
	@Id
	private int pid;
	private String pmode;
	private int amount;
	
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getMode() {
		return pmode;
	}
	public void setMode(String mode) {
		this.pmode = mode;
	}
	
	
	@Override
	public String toString() {
		return "Payment [pid=" + pid + ", mode=" + pmode + ", amount=" + amount + "]";
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	
}
