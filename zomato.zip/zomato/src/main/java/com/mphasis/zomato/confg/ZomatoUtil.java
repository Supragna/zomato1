package com.mphasis.zomato.confg;

import java.util.Properties;

import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;

import com.mphasis.zomato.beans.Cuisine;
import com.mphasis.zomato.beans.Customer;
import com.mphasis.zomato.beans.Orders;
import com.mphasis.zomato.beans.Payment;
import com.mphasis.zomato.beans.Restaurant;



public class ZomatoUtil {
	
	public static SessionFactory getSessionFactory() {
		Configuration con=new Configuration();
		Properties props=new Properties();
		props.put(Environment.DRIVER,"oracle.jdbc.driver.OracleDriver");
		props.put(Environment.URL,"jdbc:oracle:thin:@localhost:1521:xe");
		props.put(Environment.USER,"supragna");
		props.put(Environment.PASS,"supragna");
		props.put(Environment.DIALECT,"org.hibernate.dialect.OracleDialect");
		props.put(Environment.HBM2DDL_AUTO,"create");
		props.put(Environment.SHOW_SQL,"true");
		con.setProperties(props);
		con.addAnnotatedClass(Customer.class);
		con.addAnnotatedClass(Cuisine.class);
		con.addAnnotatedClass(Orders.class);
		con.addAnnotatedClass(Payment.class);
		con.addAnnotatedClass(Restaurant.class);
		StandardServiceRegistryBuilder builder=new StandardServiceRegistryBuilder().applySettings(con.getProperties());
		SessionFactory sessionfactory=con.buildSessionFactory(builder.build());
		return sessionfactory;
		
	}

}
