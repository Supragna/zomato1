package com.mphasis.zomato.beans;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="ZomatoCustomer")
public class Customer {

	private String name;
	private long contact;
	@Id
	private String email;
	private String address;
	@OneToMany(mappedBy="customer")
	private List<Cuisine> cuisine;
	
	@OneToMany(mappedBy="customer")
	private List<Orders> orders;
	
	public List<Cuisine> getCuisine() {
		return cuisine;
	}
	public void setCuisine(List<Cuisine> cuisine) {
		this.cuisine = cuisine;
	}
	public List<Orders> getOrders() {
		return orders;
	}
	public void setOrders(List<Orders> orders) {
		this.orders = orders;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getContact() {
		return contact;
	}
	public void setContact(long contact) {
		this.contact = contact;
	}
	
	@Override
	public String toString() {
		return "Customer [name=" + name + ", contact=" + contact + ", email=" + email + ", address=" + address
				+ ", cuisine=" + cuisine + ", orders=" + orders + "]";
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
}
