package com.mphasis.zomato;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;


import com.mphasis.zomato.beans.Cuisine;
import com.mphasis.zomato.beans.Customer;
import com.mphasis.zomato.beans.Orders;
import com.mphasis.zomato.beans.Payment;
import com.mphasis.zomato.beans.Restaurant;
import com.mphasis.zomato.confg.ZomatoUtil;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	Payment p1=new Payment();
    	p1.setPid(22);
    	p1.setMode("credit card");
    	p1.setAmount(2000);
    	
    	Payment p2=new Payment();
    	p2.setPid(23);
    	p2.setMode("COD");
    	p2.setAmount(1000);
    	
    	Orders od1=new Orders();
    	od1.setOrderno(1);
    	od1.setQty(1);
    	od1.setPayment(p1);
    	
    	Orders od2=new Orders();
    	od2.setOrderno(2);
    	od2.setQty(4);
    	od2.setPayment(p2);
    	
    	List<Orders> or=new ArrayList<>();
    	or.add(od1);
    	or.add(od2);
    	
    	Restaurant r1=new Restaurant();
    	r1.setRname("Bawarchi");
    	r1.setAddress("Marthalli");
    	r1.setOrders(or);
    	
    	od1.setRestaurant(r1);
    	
    	
    	Restaurant r2=new Restaurant();
    	r2.setRname("Paradise");
    	r2.setAddress("Brookefield");
    	r2.setOrders(or);
    	
    	od2.setRestaurant(r2);
    	
    	List<Restaurant> res=new ArrayList<>();
    	res.add(r1);
    	res.add(r2);
    	 
    	 Cuisine cu1=new Cuisine();
         cu1.setChinese("Noodles");
         cu1.setCuid(1);
         cu1.setDesserts("Black Current");
         cu1.setNorthindian("North Indian Thalli");
         cu1.setSouthindian("South Indian Thalli");
         
         r1.setCuisine(cu1);
         
         Cuisine cu2=new Cuisine();
         cu2.setChinese("Manchuria");
         cu2.setCuid(2);
         cu2.setDesserts("Milkshakes");
         cu2.setNorthindian("Roti");
         cu2.setSouthindian("Curd Rice");
         r2.setCuisine(cu2);
         List<Cuisine> cu=new ArrayList<>();
         cu.add(cu1);
         cu.add(cu2);
         
         cu1.setRestaurant(res);
         cu2.setRestaurant(res);
         
        Customer c1=new Customer();
        c1.setName("supragna");
        c1.setContact(16457445);
        c1.setEmail("sup@gmail.com");
        c1.setAddress("Kundanhali");
        c1.setCuisine(cu);
        c1.setOrders(or);
        od1.setCustomer(c1);
        
        cu1.setCustomer(c1);
        Customer c2=new Customer();
        c2.setName("pragna");
        c2.setContact(65457445);
        c2.setEmail("pragna@gmail.com");
        c2.setAddress("CMRIT");
        c2.setOrders(or);
        cu2.setCustomer(c2);
        od2.setCustomer(c2);
      /*  List<Customer> cust=new ArrayList<>();
        cust.add(c1);
        cust.add(c2);
       */
        SessionFactory sf=ZomatoUtil.getSessionFactory();
		Session session=sf.openSession();
		Transaction tr=session.beginTransaction();
		//session.save(cust);
		session.save(p1);
		session.save(p2);
		session.save(cu1);
		session.save(cu2);
		session.save(r1);
		session.save(r2);
		session.save(od2);
		session.save(od1);
		
		session.save(c1);
		session.save(c2);
		tr.commit();
		session.close();
        
        		
    }
}
