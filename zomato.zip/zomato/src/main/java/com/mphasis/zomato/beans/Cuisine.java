package com.mphasis.zomato.beans;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="cuisine")
public class Cuisine {
	private String northindian;
	private String southindian;
	private String chinese;
	private String desserts;
	@Id
	private int cuid;
	@ManyToOne
	private Customer customer;
	
	@OneToMany(mappedBy="cuisine")
	private List<Restaurant> restaurant;
	@Override
	public String toString() {
		return "Cuisine [northindian=" + northindian + ", southindian=" + southindian + ", chinese=" + chinese
				+ ", desserts=" + desserts + ", cuid=" + cuid + ", customer=" + customer + ", restaurant=" + restaurant
				+ "]";
	}
	public int getCuid() {
		return cuid;
	}
	public void setCuid(int cuid) {
		this.cuid = cuid;
	}
	
	
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public String getNorthindian() {
		return northindian;
	}
	public void setNorthindian(String northindian) {
		this.northindian = northindian;
	}
	public String getSouthindian() {
		return southindian;
	}
	public void setSouthindian(String southindian) {
		this.southindian = southindian;
	}
	public String getChinese() {
		return chinese;
	}
	public void setChinese(String chinese) {
		this.chinese = chinese;
	}
	public String getDesserts() {
		return desserts;
	}
	public void setDesserts(String desserts) {
		this.desserts = desserts;
	}
	public List<Restaurant> getRestaurant() {
		return restaurant;
	}
	public void setRestaurant(List<Restaurant> restaurant) {
		this.restaurant = restaurant;
	}
	
	
	

}
